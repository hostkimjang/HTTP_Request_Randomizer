__author__ = 'kimjang'

__version__ = '0.0.1'

__title__ = 'http_request_randomizer_fix'
__description__ = 'A package using public proxies to randomise http requests'
__uri__ = 'http://pgaref.com/blog/python-proxy'

__author__ = 'Panagiotis Garefalakis kimjang'
__email__ = 'ys02132286@gmail.com'

__license__ = 'MIT'
__copyright__ = 'Copyright (c) 2020 ' + __author__
